# Dimension Dual Theme — Claude Context

## Project Overview
**Dimension Dual** — Corporate/tech company site.
Custom WordPress theme built from scratch with Full Site Editing (FSE).

## Stack
| Layer       | Technology                                        |
|-------------|----------------------------------------------------|
| CMS         | WordPress with FSE                                |
| CSS         | Tailwind CSS v4 via Vite (`@tailwindcss/vite`)     |
| Build       | Vite + TailPress framework (`pnpm dev` / `pnpm build`) |
| Fonts       | Golos, Instrument Serif via Google Fonts           |

> ⚠️ **Build note:** the theme currently has two CSS source trees. Only `resources/css/` + `resources/js/` are wired up (imported by `functions.php` via `TailPress\Framework\Assets\ViteCompiler`, compiled by `vite.config.js` into `dist/`). The `assets/src/css/` tree + `tailwind.config.js` (Tailwind v3 style) are **not** part of the active build — leftover from an earlier setup. Edit CSS in `resources/css/`, not `assets/src/css/`.

---

## Key Commands
```bash
pnpm install   # Install dependencies
pnpm dev       # Vite dev server (watch mode)
pnpm build     # Production build → outputs to /dist (manifest read by TailPress ViteCompiler)
```
Yes — same as the previous theme, you need to run `pnpm build` after any CSS/JS change in `resources/` so WordPress picks up the compiled, hashed assets from `/dist`. There's no separate "Tailwind CLI" step; `pnpm build` already runs Tailwind v4 through the Vite plugin.

---

## Directory Structure
```
dimension-dual/
├── assets/
│   ├── src/
│   │   └── css/
│   │       ├── app.css                ← main entry, imports all layers
│   │       ├── base/
│   │       │   └── typography.css
│   │       ├── components/
│   │       │   ├── buttons.css        ← .bvt-btn and all variants
│   │       │   └── containers.css     ← .bvt-container, .bvt-section
│   │       └── blocks/
│   │           └── [name].css         ← one file per block
│   └── dist/
│       └── css/
│           └── app.css                ← compiled output (NEVER edit)
├── blocks/
│   └── [name]/
│       └── render.php
├── parts/
│   ├── header.php
│   └── footer.php
├── templates/
│   └── index.html
├── inc/
│   └── setup.php
├── functions.php
├── style.css                          ← theme header + CSS custom properties
├── theme.json                         ← WP FSE tokens
├── tailwind.config.js
└── package.json
```

---

## Color Tokens

| Token                    | Hex       | Usage                              |
|--------------------------|-----------|------------------------------------|
| `--color-bvt-blue`       | `#0077FF` | Accents, links, icons, buttons     |
| `--color-bvt-blue-dark`  | `#003C78` | Titles, hero headings, dark bg     |
| `--color-bvt-gray-mid`   | `#4A5A72` | Body text, paragraphs, labels      |
| `--color-bvt-gray-light` | `#F0F4F9` | Section backgrounds, cards bg      |
| `--color-bvt-gray-dark`  | `#353535` | Strong text, dark sections         |
| `--color-bvt-white`      | `#ffffff`  | Backgrounds, text on dark          |

Always use `var(--color-bvt-*)` in CSS. Never hardcode hex values.

---

## Typography Scale

| Token           | Size      | Usage                    |
|-----------------|-----------|--------------------------|
| `--text-h1`     | 3rem / 48px | Main page titles        |
| `--text-h2`     | 2rem / 32px | Section titles          |
| `--text-subtitle` | 1.25rem / 20px | Subtitles           |
| `--text-card`   | 1.375rem / 22px | Card titles         |
| `--text-body`   | 1.125rem / 18px | Paragraphs & lists  |
| `--text-sm`     | 0.875rem / 14px | Captions, labels    |

Font family: **Montserrat** — weights 400, 500, 600, 700.

---

## Button System

All buttons use the `.bvt-btn` base class.

| Class                  | Width  | Use case                          |
|------------------------|--------|-----------------------------------|
| `.bvt-btn`             | 140px  | Default / small                   |
| `.bvt-btn.bvt-btn--md` | 170px  | Medium actions                    |
| `.bvt-btn.bvt-btn--lg` | 180px  | Large / hero CTAs                 |

Height is always **50px** across all sizes.

**Variants:**
- `.bvt-btn` — solid blue (default)
- `.bvt-btn--outline` — transparent with blue border
- `.bvt-btn--outline-white` — transparent with white border (for dark bg)
- `.bvt-btn--dark` — solid dark blue

**Example usage:**
```html
<a href="#" class="bvt-btn">Get Started</a>
<a href="#" class="bvt-btn bvt-btn--md bvt-btn--outline">Learn More</a>
<a href="#" class="bvt-btn bvt-btn--lg">Contact Us</a>
```

---

## Absolute Rules — CSS

### Naming convention: BEM with block prefix `bvt-`
Pattern: `[block]__[element]--[modifier]`

| ✅ CORRECT               | ❌ WRONG           |
|--------------------------|--------------------|
| `.hero__title`           | `.title`           |
| `.header__nav`           | `.nav`             |
| `.services__card`        | `.card`            |
| `.hero__title--large`    | `.large`           |
| `.bvt-btn--outline`      | `.btn-outline`     |

- **Shared cross-block classes** → prefix `.bvt-`
- **Tailwind in HTML** → ONLY for one-off non-repeatable tweaks
- **Structural / repeated styles** → ALWAYS in `@layer components`
- **Never hardcode colors** → always `var(--color-bvt-*)`
- **One CSS file per block** → `assets/src/css/blocks/[block-name].css`

### @layer components vs Tailwind in HTML
- `@layer components` → layout, repeatable patterns, BEM classes
- `Tailwind utilities in HTML` → minor one-off adjustments (e.g., `mt-4` on a single element)

---

## Absolute Rules — PHP

- `render.php` → markup + semantic classes only, **no complex logic**
- Complex logic → goes in `inc/` as named functions
- Always sanitize output:
```php
esc_html()      // plain text
esc_url()       // URLs
wp_kses_post()  // HTML content
```
- No closing `?>` at end of PHP-only files
- Use `defined('ABSPATH') || exit;` at top of all PHP files

---

## WordPress FSE Rules

- Templates go in `/templates/` as `.html` files
- Template parts go in `/parts/` as `.php` or `.html` files
- Custom blocks go in `/blocks/[name]/render.php`
- Register blocks in `functions.php` or `inc/blocks.php`
- Use `theme.json` for WP color/font presets — keep in sync with CSS tokens

---

## Adding a New Block

1. Create `/blocks/[name]/render.php`
2. Create `/assets/src/css/blocks/[name].css`
3. Import the CSS file in `assets/src/css/app.css`
4. Register the block in `functions.php`

---

## Design Principles

- Mobile-first always
- Sections alternate between `--white` and `--light` backgrounds unless design specifies otherwise
- Dark sections (`--dark` or `--blue`) use white text and `bvt-btn--outline-white`
- Titles always in `--color-bvt-blue-dark` (#003C78) unless on dark background
- Body text always in `--color-bvt-gray-mid` (#4A5A72) unless on dark background
- Blue (#0077FF) is for interactive elements: buttons, links, icons, highlights

---

## New Brand Design Tokens — Dimension Dual

> These are the values for the new brand system. Not yet implemented in `style.css` / `theme.json` / `resources/css` (still on the old BVT blue palette + Montserrat) — recorded here as the source of truth for the upcoming update.

### Fonts
- **Golos** — (role TBD — likely headings/UI)
- **Instrument Serif** — (role TBD — likely display/accent text)

### Colors

| Token                  | Hex       | Name (ES)      |
|------------------------|-----------|-----------------|
| `--color-green-light`  | `#BFFF70` | Verde pálido    |
| `--color-green`        | `#2C856B` | Verde           |
| `--color-purple`       | `#6B3DFE` | Morado          |
| `--color-brick`        | `#DB2728` | Ladrillo        |
| `--color-orange`       | `#E65924` | Naranja         |
| `--color-orange-light` | `#F18B20` | Naranja pálido  |

### Typography Sizes

Reuses the existing `--text-*` scale where the size lines up; adds two new button-text tokens.

| Token             | Size  | Name (ES)       |
|-------------------|-------|------------------|
| `--text-h1`       | 48px  | Título sección   |
| `--text-h2`       | 32px  | Título grande    |
| `--text-subtitle` | 24px  | Título subtítulo *(was 20px — updated)* |
| `--text-body`     | 18px  | Contenido sección |
| `--text-btn-lg`   | 18px  | Texto botón grande |
| `--text-btn-md`   | 16px  | Texto botón mediano |

### Spacing & Layout

- Every section/block: **60px** internal padding top and bottom
- Max content container width: **1200px** — applies to the *inner content* only; many sections are full-width (background bleeds edge-to-edge, content inside stays capped at 1200px and centered)
- Mobile: native **30px** left/right internal padding on all sections, so content never touches the screen edges
