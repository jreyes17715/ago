<?php
/**
 * Footer — Dimension Dual
 * Fijo en todas las páginas del sitio (no es un bloque de Gutenberg).
 * Fila 1: título CTA con acento + botón "Cotiza tu servicio".
 * Fila 2: 3 columnas — marca/copyright, contacto/redes, menú + "únete al equipo".
 * Editable desde Apariencia → Personalizar → Footer (global).
 *
 * @package Dimension Dual
 */

defined( 'ABSPATH' ) || exit;

$footer_richtext_tags = dd_footer_allowed_richtext();

// Mismos valores por defecto que el Personalizador (dd_footer_defaults()),
// para que el footer se vea bien incluso antes de tocar nada ahí.
$d = dd_footer_defaults();

$footer_cta_title      = get_theme_mod( 'dd_footer_cta_title', $d['dd_footer_cta_title'] );
$footer_cta_btn_text   = get_theme_mod( 'dd_footer_cta_button_text', $d['dd_footer_cta_button_text'] );
$footer_cta_btn_url    = get_theme_mod( 'dd_footer_cta_button_url', $d['dd_footer_cta_button_url'] );

$footer_logo_id      = get_theme_mod( 'dd_footer_logo', $d['dd_footer_logo'] );
$footer_bg_id        = get_theme_mod( 'dd_footer_background', $d['dd_footer_background'] );
$footer_bg_url       = $footer_bg_id ? wp_get_attachment_image_url( $footer_bg_id, 'full' ) : '';
$footer_copyright_1  = get_theme_mod( 'dd_footer_copyright_text', $d['dd_footer_copyright_text'] );
$footer_copyright_2  = get_theme_mod( 'dd_footer_copyright_sub', $d['dd_footer_copyright_sub'] );

$footer_phone     = get_theme_mod( 'dd_footer_phone', $d['dd_footer_phone'] );
$footer_email     = get_theme_mod( 'dd_footer_email', $d['dd_footer_email'] );
$footer_address   = get_theme_mod( 'dd_footer_address', $d['dd_footer_address'] );
$footer_whatsapp  = get_theme_mod( 'dd_footer_whatsapp_url', $d['dd_footer_whatsapp_url'] );
$footer_linkedin  = get_theme_mod( 'dd_footer_linkedin_url', $d['dd_footer_linkedin_url'] );
$footer_instagram = get_theme_mod( 'dd_footer_instagram_url', $d['dd_footer_instagram_url'] );

$footer_join_text     = get_theme_mod( 'dd_footer_join_text', $d['dd_footer_join_text'] );
$footer_join_btn_text = get_theme_mod( 'dd_footer_join_button_text', $d['dd_footer_join_button_text'] );
$footer_join_btn_url  = get_theme_mod( 'dd_footer_join_button_url', $d['dd_footer_join_button_url'] );

// Icono flecha diagonal — mismo path que el botón del hero, para mantener
// consistencia visual en todos los CTA del sitio.
// Markup estatico (no viene de input de usuario), se imprime directo igual
// que en blocks/hero/render.php — evita que wp_kses le cambie a minusculas
// el atributo "viewBox" (rompe el render del SVG en algunos casos).
$dd_arrow_icon = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4 12L12 4M12 4H5M12 4V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
$dd_arrow_icon_sm = '<svg class="footer__link-icon" width="10" height="10" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4 12L12 4M12 4H5M12 4V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

// Fondo administrable (opcional): si hay imagen, reemplaza por completo el
// degradado morado/negro por defecto — solo la imagen, sin overlay. El
// tamaño/posicion (ancho completo, apoyada abajo, sin deformarse) ya vive
// en footer.css, no hace falta repetirlo acá.
$footer_style = '';
if ( $footer_bg_url ) {
    $footer_style = 'background-image:url(' . esc_url( $footer_bg_url ) . ');';
}
?>

    <!-- ═══════════════════════════════════════
         FOOTER
    ════════════════════════════════════════ -->
    <footer id="colophon" class="site-footer" role="contentinfo"<?php echo $footer_style ? ' style="' . esc_attr( $footer_style ) . '"' : ''; ?>>

        <!-- Fila 1 — CTA principal -->
        <?php if ( $footer_cta_title || $footer_cta_btn_text ) : ?>
            <div class="footer__cta">
                <div class="footer__container footer__cta-row">

                    <?php if ( $footer_cta_title ) : ?>
                        <h2 class="footer__cta-title"><?php echo wp_kses( $footer_cta_title, $footer_richtext_tags ); ?></h2>
                    <?php endif; ?>

                    <?php if ( $footer_cta_btn_text ) : ?>
                        <div class="footer__cta-action">
                            <a href="<?php echo esc_url( $footer_cta_btn_url ); ?>" class="dd-btn dd-btn--purple">
                                <?php echo esc_html( $footer_cta_btn_text ); ?>
                            </a>
                            <span class="dd-btn-icon dd-btn-icon--purple" aria-hidden="true">
                                <?php echo $dd_arrow_icon; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico, ver comentario arriba. ?>
                            </span>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        <?php endif; ?>

        <!-- Fila 2 — 3 columnas -->
        <div class="footer__main">
            <div class="footer__container footer__grid">

                <!-- Columna 1: marca -->
                <div class="footer__col footer__col--brand">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer__logo-link">
                        <?php if ( $footer_logo_id ) :
                            $footer_logo_url = wp_get_attachment_image_url( $footer_logo_id, 'full' );
                            $footer_logo_alt = get_post_meta( $footer_logo_id, '_wp_attachment_image_alt', true ) ?: get_bloginfo( 'name' );
                            ?>
                            <img src="<?php echo esc_url( $footer_logo_url ); ?>" alt="<?php echo esc_attr( $footer_logo_alt ); ?>" class="footer__logo" />
                        <?php else : ?>
                            <span class="footer__logo-placeholder"><?php bloginfo( 'name' ); ?></span>
                        <?php endif; ?>
                    </a>

                    <?php if ( $footer_copyright_1 || $footer_copyright_2 ) : ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer__copyright">
                            <?php if ( $footer_copyright_1 ) : ?>
                                <?php echo esc_html( $footer_copyright_1 ); ?><br />
                            <?php endif; ?>
                            <?php if ( $footer_copyright_2 ) : ?>
                                <?php echo esc_html( $footer_copyright_2 ); ?>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Columna 2: contacto y redes -->
                <div class="footer__col footer__col--contact">

                    <?php if ( $footer_phone ) : ?>
                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $footer_phone ) ); ?>" class="footer__contact-item">
                            <?php echo esc_html( $footer_phone ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( $footer_email ) : ?>
                        <a href="mailto:<?php echo esc_attr( $footer_email ); ?>" class="footer__contact-item">
                            <?php echo esc_html( $footer_email ); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ( $footer_address ) : ?>
                        <p class="footer__contact-item footer__address">
                            <?php esc_html_e( 'Dirección:', 'dimension-dual' ); ?> <?php echo nl2br( esc_html( $footer_address ) ); ?>
                        </p>
                    <?php endif; ?>

                    <?php if ( $footer_whatsapp || $footer_linkedin || $footer_instagram ) : ?>
                        <ul class="footer__social">
                            <?php if ( $footer_whatsapp ) : ?>
                                <li>
                                    <a href="<?php echo esc_url( $footer_whatsapp ); ?>" target="_blank" rel="noopener noreferrer">
                                        <?php esc_html_e( 'WhatsApp Business', 'dimension-dual' ); ?>
                                        <?php echo $dd_arrow_icon_sm; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if ( $footer_linkedin ) : ?>
                                <li>
                                    <a href="<?php echo esc_url( $footer_linkedin ); ?>" target="_blank" rel="noopener noreferrer">
                                        <?php esc_html_e( 'LinkedIn', 'dimension-dual' ); ?>
                                        <?php echo $dd_arrow_icon_sm; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if ( $footer_instagram ) : ?>
                                <li>
                                    <a href="<?php echo esc_url( $footer_instagram ); ?>" target="_blank" rel="noopener noreferrer">
                                        <?php esc_html_e( 'Instagram', 'dimension-dual' ); ?>
                                        <?php echo $dd_arrow_icon_sm; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    <?php endif; ?>
                </div>

                <!-- Columna 3: menú + CTA secundario -->
                <div class="footer__col footer__col--menu">

                    <?php if ( has_nav_menu( 'footer' ) ) : ?>
                        <nav class="footer__nav" aria-label="<?php esc_attr_e( 'Menú de footer', 'dimension-dual' ); ?>">
                            <?php
                            wp_nav_menu( [
                                'theme_location' => 'footer',
                                'container'      => false,
                                'menu_class'     => 'footer__menu',
                                'fallback_cb'    => false,
                                'depth'          => 1,
                            ] );
                            ?>
                        </nav>
                    <?php elseif ( has_nav_menu( 'primary' ) ) : ?>
                        <nav class="footer__nav" aria-label="<?php esc_attr_e( 'Menú', 'dimension-dual' ); ?>">
                            <?php
                            wp_nav_menu( [
                                'theme_location' => 'primary',
                                'container'      => false,
                                'menu_class'     => 'footer__menu',
                                'fallback_cb'    => false,
                                'depth'          => 1,
                            ] );
                            ?>
                        </nav>
                    <?php endif; ?>

                    <?php if ( $footer_join_text ) : ?>
                        <p class="footer__join-text"><?php echo wp_kses( $footer_join_text, $footer_richtext_tags ); ?></p>
                    <?php endif; ?>

                    <?php if ( $footer_join_btn_text ) : ?>
                        <div class="footer__cta-action">
                            <a href="<?php echo esc_url( $footer_join_btn_url ); ?>" class="dd-btn dd-btn--white">
                                <?php echo esc_html( $footer_join_btn_text ); ?>
                            </a>
                            <span class="dd-btn-icon dd-btn-icon--white" aria-hidden="true">
                                <?php echo $dd_arrow_icon; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico, ver comentario arriba. ?>
                            </span>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>

    </footer><!-- #colophon -->

</div><!-- #page .site -->

<?php wp_footer(); ?>
</body>
</html>
