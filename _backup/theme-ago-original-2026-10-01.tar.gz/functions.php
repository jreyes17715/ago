<?php
defined( 'ABSPATH' ) || exit;

use TailPress\Framework\Theme;
use TailPress\Framework\Assets\ViteCompiler;

require_once get_template_directory() . '/vendor/autoload.php';

/* ------------------------------------------------------------------ */
/*  Google Fonts                                                       */
/* ------------------------------------------------------------------ */
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'dimension-dual-google-fonts',
        'https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600;700&family=Instrument+Serif:ital@0;1&display=swap',
        [],
        null
    );
} );

// Mismas fuentes dentro del editor de bloques, para que la vista previa coincida con el frontend.
add_action( 'enqueue_block_editor_assets', function () {
    wp_enqueue_style(
        'dimension-dual-google-fonts-editor',
        'https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600;700&family=Instrument+Serif:ital@0;1&display=swap',
        [],
        null
    );
} );

/* ------------------------------------------------------------------ */
/*  Permitir subir SVG en la Biblioteca de medios                      */
/*  (para los iconos de los bloques: servicios, etc.)                  */
/* ------------------------------------------------------------------ */
add_filter( 'upload_mimes', function ( array $mimes ) : array {
    // Solo administradores: subir SVG sin filtrar tiene riesgo de XSS si lo hace cualquier usuario.
    if ( current_user_can( 'manage_options' ) ) {
        $mimes['svg'] = 'image/svg+xml';
    }
    return $mimes;
} );

// Evita que WordPress rechace el SVG por no poder leer sus dimensiones "reales".
add_filter( 'wp_check_filetype_and_ext', function ( $data, $file, $filename, $mimes ) {
    if ( ! $data['ext'] || ! $data['type'] ) {
        $filetype = wp_check_filetype( $filename, [ 'svg' => 'image/svg+xml' ] );
        if ( 'svg' === $filetype['ext'] ) {
            $data['ext']             = 'svg';
            $data['type']            = 'image/svg+xml';
            $data['proper_filename'] = $filename;
        }
    }
    return $data;
}, 10, 4 );

/* ------------------------------------------------------------------ */
/*  Theme setup                                                        */
/* ------------------------------------------------------------------ */
add_action( 'after_setup_theme', function () {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'html5', [
        'comment-list', 'comment-form', 'search-form',
        'gallery', 'caption', 'style', 'script',
    ] );
    add_theme_support( 'custom-logo', [
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ] );

    register_nav_menus( [
        'primary' => __( 'Menu Principal', 'dimension-dual' ),
        'footer'  => __( 'Menu Footer',    'dimension-dual' ),
    ] );
} );

/* ------------------------------------------------------------------ */
/*  Enqueue assets via TailPress + Vite                               */
/* ------------------------------------------------------------------ */
Theme::instance()
    ->assets( fn( $manager ) => $manager
        ->withCompiler( new ViteCompiler, fn( $compiler ) => $compiler
            ->registerAsset( 'resources/css/app.css' )
            ->registerAsset( 'resources/js/app.js' )
            ->editorStyleFile( 'resources/css/editor-style.css' )
        )
        ->enqueueAssets()
    );

/* ------------------------------------------------------------------ */
/*  Load block registration                                            */
/* ------------------------------------------------------------------ */
require_once get_template_directory() . '/inc/post-types.php';
require_once get_template_directory() . '/inc/breadcrumb.php';
require_once get_template_directory() . '/inc/blocks/register-blocks.php';
require_once get_template_directory() . '/inc/seo.php';
require_once get_template_directory() . '/inc/seo-fields.php';
require_once get_template_directory() . '/inc/blog-settings.php';
require_once get_template_directory() . '/inc/schema.php';

/* ------------------------------------------------------------------ */
/*  Menú — ítem activo para CPT                                        */
/*  Marca el ítem de la página "Servicios" como ancestro activo        */
/*  cuando se está viendo el detalle de un servicio individual.        */
/* ------------------------------------------------------------------ */
add_filter( 'nav_menu_css_class', function ( array $classes, WP_Post $item ) : array {

    // ── Servicios: marcar el ítem padre cuando se ve un servicio individual ──
    if ( is_singular( 'servicios' ) ) {
        $services_page = get_page_by_path( 'servicios' );
        if (
            $services_page
            && $item->type === 'post_type'
            && $item->object === 'page'
            && (int) $item->object_id === (int) $services_page->ID
        ) {
            $classes[] = 'current-menu-ancestor';
            $classes[] = 'current-menu-parent';
        }
    }

    // ── Blog: marcar el ítem padre cuando se ve el detalle de un post ──
    if ( is_singular( 'post' ) ) {
        // Intentar con "Posts page" de WordPress primero,
        // si no, buscar la página por slug 'blog'
        $blog_page_id = (int) get_option( 'page_for_posts' );
        if ( ! $blog_page_id ) {
            $blog_page = get_page_by_path( 'blog' );
            if ( $blog_page ) {
                $blog_page_id = (int) $blog_page->ID;
            }
        }
        if (
            $blog_page_id
            && $item->type === 'post_type'
            && $item->object === 'page'
            && (int) $item->object_id === $blog_page_id
        ) {
            $classes[] = 'current-menu-ancestor';
            $classes[] = 'current-menu-parent';
        }
    }

    return $classes;
}, 10, 2 );

/* ------------------------------------------------------------------ */
/*  Custom Post Types                                                  */
/* ------------------------------------------------------------------ */
require_once get_template_directory() . '/inc/customizer.php';
