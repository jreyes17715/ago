<?php
/**
 * Cabecera del tema — Dimension Dual
 * Barra transparente sobre el hero: logo + menú + toggle mobile.
 *
 * @package Dimension Dual
 */

defined('ABSPATH') || exit;

// El panel del menú mobile reutiliza la misma info de contacto/redes del
// footer (dd_footer_defaults()) para no duplicar campos administrables.
$dd_footer_defaults = dd_footer_defaults();
$dd_header_defaults = dd_header_defaults();

$header_phone     = get_theme_mod( 'dd_footer_phone', $dd_footer_defaults['dd_footer_phone'] );
$header_email     = get_theme_mod( 'dd_footer_email', $dd_footer_defaults['dd_footer_email'] );
$header_whatsapp  = get_theme_mod( 'dd_footer_whatsapp_url', $dd_footer_defaults['dd_footer_whatsapp_url'] );
$header_linkedin  = get_theme_mod( 'dd_footer_linkedin_url', $dd_footer_defaults['dd_footer_linkedin_url'] );
$header_instagram = get_theme_mod( 'dd_footer_instagram_url', $dd_footer_defaults['dd_footer_instagram_url'] );

$header_cta_text = get_theme_mod( 'dd_header_cta_text', $dd_header_defaults['dd_header_cta_text'] );
$header_cta_url  = get_theme_mod( 'dd_header_cta_url', $dd_header_defaults['dd_header_cta_url'] );

// Logo — version negra administrable, se usa en el header claro (paginas
// sin el bloque Hero, ej. Sobre Nosotros). Si no se subio nada, se usa el
// logo normal (Identidad del sitio) igual que antes.
$header_logo_dark_id  = (int) get_theme_mod( 'dd_header_logo_dark', $dd_header_defaults['dd_header_logo_dark'] );
$header_logo_dark_url = $header_logo_dark_id ? wp_get_attachment_image_url( $header_logo_dark_id, 'full' ) : '';

// Markup estatico (no viene de input de usuario) — se imprime directo,
// mismo criterio que footer.php, para no romper "viewBox" con wp_kses.
$dd_arrow_icon    = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4 12L12 4M12 4H5M12 4V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
$dd_arrow_icon_sm = '<svg class="footer__link-icon" width="10" height="10" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M4 12L12 4M12 4H5M12 4V11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

// Header claro/oscuro sin duplicar el menu: si la pagina actual trae el
// bloque hero (fondo oscuro) el header usa texto blanco (por defecto);
// cualquier otra pagina (fondo claro, ej. Sobre Nosotros) usa la variante
// "--light" (texto negro, hover/activo naranja). Un solo <nav>, un solo menu.
$dd_current_id   = get_queried_object_id();
$dd_header_dark  = $dd_current_id ? has_block( 'dimension-dual/hero', $dd_current_id ) : false;
$dd_header_class = 'site-header' . ( $dd_header_dark ? '' : ' site-header--light' );
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">

    <header id="masthead" class="<?php echo esc_attr( $dd_header_class ); ?>" role="banner">
        <div class="header__inner">

            <!-- Logotipo -->
            <div class="header__brand">
                <?php if ( ! $dd_header_dark && $header_logo_dark_url ) : ?>
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                        <img src="<?php echo esc_url( $header_logo_dark_url ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
                    </a>
                <?php elseif (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="header__site-name" rel="home">
                        <?php bloginfo('name'); ?>
                    </a>
                <?php endif; ?>
            </div>

            <!-- Menú principal -->
            <?php if (has_nav_menu('primary')) : ?>
                <nav class="header__nav" role="navigation"
                     aria-label="<?php esc_attr_e('Menú principal', 'dimension-dual'); ?>">
                    <?php
                    wp_nav_menu([
                        'theme_location' => 'primary',
                        'container'      => false,
                        'menu_class'     => 'header__menu',
                        'fallback_cb'    => false,
                        'depth'          => 1,
                    ]);
                    ?>

                    <!-- Contenido extra: solo visible dentro del panel mobile
                         (buscador, contacto, CTA, redes) — oculto en desktop. -->
                    <div class="header__nav-extra">
                        <form role="search" method="get" class="header__search" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                            <label class="screen-reader-text" for="header-search-input"><?php esc_html_e( 'Buscar', 'dimension-dual' ); ?></label>
                            <input type="search" id="header-search-input" class="header__search-input" name="s"
                                   placeholder="<?php esc_attr_e( 'Buscar...', 'dimension-dual' ); ?>"
                                   value="<?php echo esc_attr( get_search_query() ); ?>" />
                            <button type="submit" class="header__search-submit" aria-label="<?php esc_attr_e( 'Buscar', 'dimension-dual' ); ?>">
                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                    <circle cx="8" cy="8" r="6.25" stroke="currentColor" stroke-width="1.5"/>
                                    <path d="M16 16L12.5 12.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                            </button>
                        </form>

                        <?php if ( $header_phone || $header_email ) : ?>
                            <div class="header__nav-contact">
                                <?php if ( $header_phone ) : ?>
                                    <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $header_phone ) ); ?>"><?php echo esc_html( $header_phone ); ?></a>
                                <?php endif; ?>
                                <?php if ( $header_email ) : ?>
                                    <a href="mailto:<?php echo esc_attr( $header_email ); ?>"><?php echo esc_html( $header_email ); ?></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if ( $header_cta_text ) : ?>
                            <div class="header__nav-cta">
                                <a href="<?php echo esc_url( $header_cta_url ); ?>" class="dd-btn dd-btn--green-light">
                                    <?php echo esc_html( $header_cta_text ); ?>
                                </a>
                                <span class="dd-btn-icon dd-btn-icon--green-light" aria-hidden="true">
                                    <?php echo $dd_arrow_icon; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                </span>
                            </div>
                        <?php endif; ?>

                        <?php if ( $header_whatsapp || $header_linkedin || $header_instagram ) : ?>
                            <ul class="header__nav-social">
                                <?php if ( $header_whatsapp ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( $header_whatsapp ); ?>" target="_blank" rel="noopener noreferrer">
                                            <?php esc_html_e( 'WhatsApp Business', 'dimension-dual' ); ?>
                                            <?php echo $dd_arrow_icon_sm; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if ( $header_linkedin ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( $header_linkedin ); ?>" target="_blank" rel="noopener noreferrer">
                                            <?php esc_html_e( 'LinkedIn', 'dimension-dual' ); ?>
                                            <?php echo $dd_arrow_icon_sm; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                <?php if ( $header_instagram ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( $header_instagram ); ?>" target="_blank" rel="noopener noreferrer">
                                            <?php esc_html_e( 'Instagram', 'dimension-dual' ); ?>
                                            <?php echo $dd_arrow_icon_sm; // phpcs:ignore WordPress.Security.EscapeOutput -- markup estatico. ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </nav>
            <?php endif; ?>

            <!-- Botón hamburguesa (mobile) -->
            <button class="header__toggle" type="button"
                    aria-label="<?php esc_attr_e('Abrir menú', 'dimension-dual'); ?>"
                    aria-expanded="false" aria-controls="masthead">
                <span class="header__toggle-bar"></span>
                <span class="header__toggle-bar"></span>
                <span class="header__toggle-bar"></span>
            </button>

        </div>
    </header><!-- #masthead -->
